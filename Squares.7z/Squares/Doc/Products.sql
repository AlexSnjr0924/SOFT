/* Test tables. Products and categories */
use TestDB;
declare
  @cnt int, @i int, @cnt1 int, @t_user varchar(16), @t_name varchar(24), @sql varchar(MAX);
begin
  -- Table 'Products'
  set @t_user = 'dbo';
  set @t_name = 'Products';
  select @cnt = COUNT(*) from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA = @t_user and TABLE_NAME = @t_name;
  if @cnt = 0 begin
    -- Create table 'Products'
    set @sql = CONCAT('create table ', @t_user, '.', @t_name, ' (prod_id int not null, prod_name varchar(32))');
    execute(@sql);                                                                                   
  end;

  -- Table 'Products'. Data
  set @sql = CONCAT('truncate table ', @t_user, '.', @t_name);
  execute(@sql);
  set @i = 0; while @i < 20 begin
    -- Next record
    set @i = @i + 1;
    set @sql = CONCAT('insert into ', @t_user, '.', @t_name, '(prod_id, prod_name)', ' values (', @i, ', ''MyProduct_'
      , RIGHT(CAST(1000 + @i as char(4)), 3), ''')');
    execute(@sql);
  end;

  -- Table 'Categories'
  set @t_name = 'Categories';
  select @cnt = COUNT(*) from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA = @t_user and TABLE_NAME = @t_name;
  if @cnt = 0 begin
    -- Create table 'Categories'
    set @sql = CONCAT('create table ', @t_user, '.', @t_name, ' (cat_id int not null, cat_name varchar(32))');
    execute(@sql);                                                                                   
  end;

  -- Table 'Categories'. Data
  set @sql = CONCAT('truncate table ', @t_user, '.', @t_name);
  execute(@sql);
  set @i = 0; while @i < 10 begin
    -- Next record
    set @i = @i + 1;
    set @sql = CONCAT('insert into ', @t_user, '.', @t_name, '(cat_id, cat_name)', ' values (', @i, ', ''MyCategory_'
      , CHAR(64 + @i), ''')');
    execute(@sql);
  end;

  -- Table 'JoinCatProd'
  set @t_name = 'JoinCatProd';
  select @cnt = COUNT(*) from INFORMATION_SCHEMA.TABLES where TABLE_SCHEMA = @t_user and TABLE_NAME = @t_name;
  if @cnt = 0 begin
    -- Create table 'Categories'
    set @sql = CONCAT('create table ', @t_user, '.', @t_name, ' (cat_id int not null, prod_id int not null)');
    execute(@sql);                                                                                   
  end;

  -- Table 'JoinCatProd'. Data. Info
  set @sql = CONCAT('truncate table ', @t_user, '.', @t_name);
  execute(@sql);
  select @cnt = COUNT(*) from dbo.Products;
  select @cnt1 = COUNT(*) from dbo.Categories;

  -- Table 'JoinCatProd'. Data
  set @i = 0; while @i < @cnt * @cnt1 begin
    -- Next record
    if @i % 43 in (11,12) begin
      set @sql = CONCAT('insert into ', @t_user, '.', @t_name, '(cat_id, prod_id)', ' values ('
        ,  @i / @cnt + 1, ',', (@i % @cnt) + 1, ')');
      execute(@sql);
    end;
    set @i = @i + 1;
  end;

  -- Result
  select C.cat_id, C.cat_name, P.prod_id, P.prod_name
    from dbo.JoinCatProd as CP
    join dbo.Categories as C on C.cat_id = CP.cat_id
    join dbo.Products as P on P.prod_id = CP.prod_id
   union all
  select C.cat_id, C.cat_name, CP.prod_id, null as prod_name
    from dbo.Categories as C
    left join dbo.JoinCatProd as CP on CP.cat_id = C.cat_id
   where CP.cat_id is null
   union all
  select CP.cat_id, null as cat_name, P.prod_id, P.prod_name
    from dbo.Products as P
    left join dbo.JoinCatProd as CP on CP.prod_id = P.prod_id
   where CP.prod_id is null
   order by 1, 3;

  -- Test
  --select cat_id, cat_name from dbo.Categories order by cat_id;
  --select prod_id, prod_name  from dbo.Products order by prod_id;
end;
/**/